# Spreadsheet Generator

A simple Python script to generate a spreadsheet with sample data using LLMs such as Deepseek or ChatGPT.
